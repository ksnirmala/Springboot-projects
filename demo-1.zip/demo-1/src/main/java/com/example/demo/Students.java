package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;

public class Students {
	private int sid;
	private String sname;
	@Autowired
	private Laptop laptop;
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public Laptop getLaptop() {
		return laptop;
	}
	public void setLaptop(Laptop laptop) {
		this.laptop = laptop;
	}
	@Override
	public String toString() {
		return "Students [sid=" + sid + ", sname=" + sname + ", laptop=" + laptop + "]";
	}
	
public void display() {
	// TODO Auto-generated method stub
	System.out.println("inside student");
	laptop.display();
	
}
}
